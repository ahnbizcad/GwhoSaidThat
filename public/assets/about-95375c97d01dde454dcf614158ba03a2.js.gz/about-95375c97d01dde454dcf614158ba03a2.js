(function() {
  $(document).ready(function() {
    return $('[data-toggle="tooltip"]').tooltip();
  });

}).call(this);
